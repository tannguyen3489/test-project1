window.$ = window.jQuery = require('jquery');
require('bootstrap');
require('jquery-validation');
require('lodash');

